---
name: Bug report
about: Something is broken in Breadcrumb
labels: bug
---

**Device / Android version:**

**Sven Co-op version:**

**What happened:**

**Steps to reproduce:**

**Logs (xash.log):**
