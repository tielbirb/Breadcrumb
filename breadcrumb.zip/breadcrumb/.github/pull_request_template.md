## What does this change?

## Tested on
- [ ] Device / Android version:

> Breadcrumb only targets Sven Co-op. Changes for other GoldSrc games will not be merged.
