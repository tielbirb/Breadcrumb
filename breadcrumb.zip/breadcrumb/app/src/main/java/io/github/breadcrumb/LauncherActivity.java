package io.github.breadcrumb;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

/** Checks for Sven Co-op game files, then starts the engine. */
public class LauncherActivity extends AppCompatActivity {

    /** Base folder that must contain "svencoop" (and "valve"). */
    public static File gameDir(android.content.Context c) {
        File ext = c.getExternalFilesDir(null);
        return ext != null ? ext : c.getFilesDir();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
    }

    @Override
    protected void onResume() {
        super.onResume();
        File base = gameDir(this);
        boolean ok = new File(base, "svencoop").isDirectory();

        TextView status = findViewById(R.id.status);
        Button launch = findViewById(R.id.launch);

        status.setText(ok ? "Game files found." : getString(R.string.missing_files, base.getAbsolutePath()));
        launch.setEnabled(ok);
        launch.setOnClickListener(v -> {
            Intent i = new Intent(this, EngineActivity.class);
            i.putExtra("basedir", base.getAbsolutePath());
            i.putExtra("gamedir", "svencoop");
            startActivity(i);
        });
    }
}
