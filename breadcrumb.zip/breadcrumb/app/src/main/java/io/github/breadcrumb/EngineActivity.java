package io.github.breadcrumb;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Engine host. Currently a stub: once you drop the engine's .so files into
 * app/src/main/jniLibs/<abi>/ and wire this class to SDLActivity from the
 * Xash3D FWGS Android port, loadEngine() will start the game.
 * Breadcrumb always passes "-game svencoop".
 */
public class EngineActivity extends AppCompatActivity {

    private static final String[] LIBS = { "SDL2", "xash" };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String base = getIntent().getStringExtra("basedir");
        String game = getIntent().getStringExtra("gamedir");

        TextView tv = new TextView(this);
        tv.setTextColor(0xFFFFFFFF);
        tv.setPadding(48, 48, 48, 48);

        if (loadEngine()) {
            tv.setText("Starting engine...\n-game " + game + "\n" + base);
            // TODO: hand off to SDL: argv = { "-game", game, "-log" }, XASH3D_BASEDIR = base
        } else {
            tv.setText("Engine libraries not found.\nSee README -> Engine build.");
            Toast.makeText(this, "Engine not bundled yet", Toast.LENGTH_LONG).show();
        }
        setContentView(tv);
    }

    private boolean loadEngine() {
        try {
            for (String lib : LIBS) System.loadLibrary(lib);
            return true;
        } catch (UnsatisfiedLinkError e) {
            return false;
        }
    }
}
